// Example adapted from https://p5js.org/reference/#/p5.FFT

let sound, fft, waveform, spectrum, img1;
let shaders = [];
let currentShaderIndex = 0;


let jlx;

// pass gif
let gifFrames = [];
let currentFrame = 0;
let totalFrames = 73; 
let frameDuration = 50; 
let lastFrameChangeTime = 0;

// pass gif
let gifFrames2 = [];
let currentFrame2 = 0;
let totalFrames2 = 40; 
let frameDuration2 = 70; 
let lastFrameChangeTime2 = 0;

function preload() {
  sound = loadSound(`assets/afrojack.mp3`);
  img1 = loadImage(`assets/test.jpg`);

  for (let i = 0; i < totalFrames; i++) {
    gifFrames[i] = loadImage(`assets/ballet/frame_${i}.jpg`);
  }

  for (let k = 0; k < totalFrames2; k++) {
    gifFrames2[k] = loadImage(`assets/ballet2/85c2e84c54784961af6cf7ea17c1e95cVL4NJdoxkOtV5j8N-${k}.jpg`);
  }



  shaders[0] = loadShader('../shaders/vshader.vert', '../shaders/shader0.frag');
  shaders[1] = loadShader('../shaders/vshader.vert', '../shaders/shader2.frag');
  shaders[2] = loadShader('../shaders/vshader.vert', '../shaders/shader3.frag');
  shaders[3] = loadShader('../shaders/vshader.vert', '../shaders/shader6.frag');
  shaders[4] = loadShader('../shaders/vshader.vert', '../shaders/shader4.frag');
  shaders[5] = loadShader('../shaders/vshader.vert', '../shaders/shader1.frag');
  shaders[6] = loadShader('../shaders/vshader.vert', '../shaders/shader5.frag');
}

function setup() {
  let cnv = createCanvas(windowWidth, windowHeight, WEBGL);
  cnv.mouseClicked(togglePlay);

  pixelDensity(1);

  fft = new p5.FFT();

  setInterval(() => {
    if (sound.isPlaying()) {
      toggleShader();
    }
  }, 1000);
}

function draw() {
  // `waveform` is now an array of 1024 values 
  // ranging from -1.0 to 1.0, representing the amplitude
  // of the audio signal at each frequency sample.
  // https://p5js.org/reference/#/p5.FFT/waveform
  waveform = fft.waveform();

  // Alternatively, you can also use the `analyze` method.
  // `spectrum` is now an array of 1024 values
  // ranging from 0 to 255, representing the amplitude
  // of the audio signal at each frequency sample
  // with 127 representing silence.
  // https://p5js.org/reference/#/p5.FFT/analyze
  spectrum = fft.analyze();
  // 将音频数据转换为纹理（图像）
  // Set the active shader
  shader(shaders[currentShaderIndex]);

  // gif
  let currentTime = millis();
  if (currentTime - lastFrameChangeTime > frameDuration) {
    currentFrame = (currentFrame + 1) % totalFrames;
    lastFrameChangeTime = currentTime;
  }

  let currentTime2 = millis();
  if (currentTime2 - lastFrameChangeTime2 > frameDuration2) {
    currentFrame2 = (currentFrame2 + 1) % totalFrames2;
    lastFrameChangeTime2 = currentTime2;
  }

  // using uniforms
  shaders[currentShaderIndex].setUniform('u_resolution', [width, height]);
  shaders[currentShaderIndex].setUniform('u_mouse', [mouseX, height - mouseY]);
  shaders[currentShaderIndex].setUniform('u_time', 0.001 * millis()); // time in secs
  shaders[currentShaderIndex].setUniform('u_texture', img1);
  shaders[currentShaderIndex].setUniform('u_texture_gif', gifFrames[currentFrame]);
  shaders[currentShaderIndex].setUniform('u_texture_gif2', gifFrames2[currentFrame2]);

  // The best way to pass large amounts of data to a shader
  // is by converting the data to a texture. 
  // Here, we convert the waveform and spectrum arrays to
  // p5.Image objects and send them to the shader as textures.
  let waveformAsImg = floatArrayToImage(waveform);
  shaders[currentShaderIndex].setUniform('u_waveform_tex', waveformAsImg);

  let spectrumAsImg = byteArrayToImage(spectrum);
  shaders[currentShaderIndex].setUniform('u_spectrum_tex', spectrumAsImg);


  // Draw a full screen rectangle to apply the shader to
  rect(0, 0, width, height);
}

function toggleShader() {
  // switch to the next shader
  currentShaderIndex = (currentShaderIndex + 1) % shaders.length;
}

function togglePlay() {
  if (sound.isPlaying()) {
    sound.pause();
  } else {
    sound.loop();
  }
}


function keyPressed() {
  if (key === 's') {
    console.log("Waveform:");
    console.log(waveform);

    console.log("Spectrum:");
    console.log(spectrum);
  }
}


function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

/**
 * This function takes an array of floating point values
 * between [-1, 1] and returns a p5.Image object where
 * each pixel's color has been mapped from to [0, 255].
 * @param {*} array 
 * @returns 
 */
function floatArrayToImage(array) {
  let img = createImage(array.length, 1);
  img.loadPixels();
  for (let i = 0; i < img.width; i++) {
    const val = (0.5 + 0.5 * array[i]) * 255;
    img.pixels[i * 4 + 0] = val;
    img.pixels[i * 4 + 1] = val;
    img.pixels[i * 4 + 2] = val;
    img.pixels[i * 4 + 3] = 255;
  }
  img.updatePixels();
  return img;
}

/**
 * This function takes an array of byte values
 * between [0, 255] and returns a p5.Image object
 * where each pixel's color has been set to the
 * corresponding byte value.
 * @param {*} array 
 * @returns 
 */
function byteArrayToImage(array) {
  let img = createImage(array.length, 1);
  img.loadPixels();
  for (let i = 0; i < img.width; i++) {
    const val = array[i];
    img.pixels[i * 4 + 0] = val;
    img.pixels[i * 4 + 1] = val;
    img.pixels[i * 4 + 2] = val;
    img.pixels[i * 4 + 3] = 255;
  }
  img.updatePixels();
  return img;
}

